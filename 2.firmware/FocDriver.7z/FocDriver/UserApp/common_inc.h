//
// Created by Monster on 2023/6/7.
//

#ifndef COMMON_INC_H
#define COMMON_INC_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

void receivedCommand(unsigned char *data, unsigned int size);

void Main();

#ifdef __cplusplus
}


#endif // __cplusplus

#endif // COMMON_INC_H
