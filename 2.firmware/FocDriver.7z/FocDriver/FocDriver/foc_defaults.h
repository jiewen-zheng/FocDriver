//
// Created by Monster on 2023/6/7.
//

#ifndef FOC_DEFAULTS_H
#define FOC_DEFAULTS_H

#define DEF_POWER_SUPPLY    12.0f   //!< default power supply voltage


#endif //!< FOC_DEFAULTS_H
